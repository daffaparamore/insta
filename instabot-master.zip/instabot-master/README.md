# InstaBot
https://github.com/Senitopeng/instabot.git


#ini Hanya Penggabungan,
#Ku Hanya Bantu Agar Lebih Mudah Di Gunakan.

Usage


cd instabot

pip2 install -r requirements.tx

bash instabot


#Masukkan Password Yg kamu Mau Dalam File pass txt.
